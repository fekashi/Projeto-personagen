package Interfaces

interface iPlayerClass {
    fun ClassDefine() {}
}