package org.example.Interfaces

interface iHability {
    fun HabilityDefine() {}
}