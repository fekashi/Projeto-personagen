package Interfaces

interface iRace {
    fun RaceDefine() {}

}
