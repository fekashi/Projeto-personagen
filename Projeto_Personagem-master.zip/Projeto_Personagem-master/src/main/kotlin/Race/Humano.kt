package org.example.Race

import Interfaces.iRace

class Humano : iRace {
    override fun RaceDefine() {
        print("Humano");
    }
}