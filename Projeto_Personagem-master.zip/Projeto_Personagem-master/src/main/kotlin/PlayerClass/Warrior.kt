package PlayerClass

import Interfaces.iPlayerClass

class Warrior : iPlayerClass {
    override fun ClassDefine() {
        print("Guerreiro")
    }
}