package com.example.myapplication.races

class Gnome : Race("Gnomo", mapOf(
    "Inteligência" to 2
))