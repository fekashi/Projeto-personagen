package com.example.myapplication.races

abstract class Race(val name: String, val bonuses: Map<String, Int>)