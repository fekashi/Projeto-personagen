package com.example.myapplication.races

class DragonBorn : Race("Draconato", mapOf(
    "Força" to 2,
    "Carisma" to 1
))