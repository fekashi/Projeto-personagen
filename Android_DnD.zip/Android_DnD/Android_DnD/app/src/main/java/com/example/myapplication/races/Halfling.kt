package com.example.myapplication.races

class Halfling : Race("Halfling", mapOf(
    "Destreza" to 2
))