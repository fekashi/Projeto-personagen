package com.example.myapplication.races

class Dwarf : Race("Anão", mapOf(
    "Constituição" to 2
))