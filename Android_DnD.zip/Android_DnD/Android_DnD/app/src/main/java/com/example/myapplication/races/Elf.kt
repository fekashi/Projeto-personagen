package com.example.myapplication.races

class Elf : Race("Elfo", mapOf(
    "Destreza" to 2
))